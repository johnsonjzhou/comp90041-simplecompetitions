/*
 * Student name: XXX
 * Student ID: YYY
 * LMS username: ZZZ
 */

public class Member {

}
