/*
 * Student name: XXX
 * Student ID: YYY
 * LMS username: ZZZ
 */

public class NumbersEntry extends Entry {
    private int[] numbers;
}
